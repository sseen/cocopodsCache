//
//  STDSEphemeralKeyPair+Testing.h
//  Stripe3DS2
//
//  Created by Cameron Sabol on 4/18/19.
//  Copyright © 2019 Stripe. All rights reserved.
//

#import "STDSEphemeralKeyPair.h"

NS_ASSUME_NONNULL_BEGIN

@interface STDSEphemeralKeyPair (Testing)

+ (nullable instancetype)testKeyPair;

@end

NS_ASSUME_NONNULL_END
